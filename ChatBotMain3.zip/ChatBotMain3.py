##Bryce Lauritzen
##Chatbot
##Made in Python 3.6.3

import pyttsx #importing text to speech
from chatterbot.trainers import ListTrainer #training the chatbot
from chatterbot import ChatBot #importing the actual chatbot

bot = ChatBot ('Test') #make the Chatbot

bot.set_trainer(ListTrainer) #sets the trainer up

for _file in os.listdir('Datasets'):
    chats = open('Datasets/' +_file, 'r').readlines()

bot.train(talk) #trains the bot on our text list


while True:
    request = input('You: ') ## User input
    response = bot.get_response(request) ##Bot response

    print('Bot: ', response)
    engine.say(response) ##initializing pyttsx
    engine.runAndWait() ##waiting for the system to run command

